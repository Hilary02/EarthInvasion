#include "Object.h"

Object::Object() {
}


Object::~Object()
{
}

void Object::Update()
{
}


void Object::Draw()
{
}
