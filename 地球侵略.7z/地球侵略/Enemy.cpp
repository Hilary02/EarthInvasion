#include "Enemy.h"
#include "DxLib.h"



Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

void Enemy::Update()
{
}

void Enemy::Draw(){


}


