#include "Player.h"
#include "WindowData.h"
#include "KeyManager.h"


Player::Player()
{
}

Player::Player(int x,int y){
	this->defaultX = x;
	this->defaultY = y;
}

Player::~Player()
{
}


void Player::Update()
{
}


void Player::Draw()
{
}
