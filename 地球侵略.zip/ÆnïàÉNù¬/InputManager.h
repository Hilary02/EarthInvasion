#pragma once
class InputManager
{
public:
	InputManager();
	~InputManager();
};

//KeyManageer.cpp�Œ�`�ς�
extern InputManager inputM;