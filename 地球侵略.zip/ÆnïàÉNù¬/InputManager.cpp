#include "InputManager.h"

InputManager inputM;

InputManager::InputManager()
{
}


InputManager::~InputManager()
{
}
