#include "Enemy.h"



Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

void Enemy::Update()
{
}

void Enemy::Draw()
{
}


